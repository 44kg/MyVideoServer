--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.10 (Ubuntu 10.10-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.10 (Ubuntu 10.10-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.states_db DROP CONSTRAINT states_db_pk;
ALTER TABLE public.states_db ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.states_db_id_seq;
DROP TABLE public.states_db;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: states_db; Type: TABLE; Schema: public; Owner: mainkaif
--

CREATE TABLE public.states_db (
    id integer NOT NULL,
    date date,
    "time" time without time zone,
    cpu_load real,
    free_space real,
    archive_size real,
    clients integer,
    cameras integer
);


ALTER TABLE public.states_db OWNER TO mainkaif;

--
-- Name: states_db_id_seq; Type: SEQUENCE; Schema: public; Owner: mainkaif
--

CREATE SEQUENCE public.states_db_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.states_db_id_seq OWNER TO mainkaif;

--
-- Name: states_db_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mainkaif
--

ALTER SEQUENCE public.states_db_id_seq OWNED BY public.states_db.id;


--
-- Name: states_db id; Type: DEFAULT; Schema: public; Owner: mainkaif
--

ALTER TABLE ONLY public.states_db ALTER COLUMN id SET DEFAULT nextval('public.states_db_id_seq'::regclass);


--
-- Data for Name: states_db; Type: TABLE DATA; Schema: public; Owner: mainkaif
--

COPY public.states_db (id, date, "time", cpu_load, free_space, archive_size, clients, cameras) FROM stdin;
\.
COPY public.states_db (id, date, "time", cpu_load, free_space, archive_size, clients, cameras) FROM '$$PATH$$/2912.dat';

--
-- Name: states_db_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mainkaif
--

SELECT pg_catalog.setval('public.states_db_id_seq', 23, true);


--
-- Name: states_db states_db_pk; Type: CONSTRAINT; Schema: public; Owner: mainkaif
--

ALTER TABLE ONLY public.states_db
    ADD CONSTRAINT states_db_pk PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

